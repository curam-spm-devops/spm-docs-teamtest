# Testing the GraphQL queries

There are a number of tools available for you to use when wanting to run your new GraphQL queries.

In this documentation, we are going to specify two tools which you can choose from to assist you in working with the GraphQL query creation.

You can view your GraphQL queries using the GraphQL introspection html page or Postman.
